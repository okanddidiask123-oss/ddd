Option Explicit
' Read-only OS/device/framework inspection. Output is captured by PRECHECK.cmd.
Dim fso, shell, windowsDir, wmi, systems, os, devices, dev
Dim blockers, found, osOkay, archOkay, path, ver, name, drivers, drv
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
windowsDir = shell.ExpandEnvironmentStrings("%SystemRoot%")
blockers = 0
found = 0
WScript.Echo "Vista RTL8812BU experimental driver: prerequisite/diagnostic report"
WScript.Echo "This is not a hardware compatibility test."
WScript.Echo ""
On Error Resume Next
Set wmi = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
If Err.Number <> 0 Then
    WScript.Echo "BLOCK: WMI could not be opened: " & Err.Description
    WScript.Quit 2
End If
On Error GoTo 0
Set systems = wmi.ExecQuery("SELECT Version, Caption, OSArchitecture, ServicePackMajorVersion FROM Win32_OperatingSystem")
For Each os In systems
    WScript.Echo "OS: " & os.Caption
    WScript.Echo "Version: " & os.Version
    WScript.Echo "Architecture: " & os.OSArchitecture
    WScript.Echo "Service pack: " & os.ServicePackMajorVersion
    osOkay = (Left(os.Version, 4) = "6.0.") And (os.ServicePackMajorVersion = 2)
    archOkay = (InStr(CStr(os.OSArchitecture), "64") > 0)
    If Not osOkay Or Not archOkay Then
        WScript.Echo "BLOCK: this package is restricted to Vista SP2 x64."
        blockers = blockers + 1
    End If
Next
WScript.Echo ""
For Each name In Array("Wdf01000.sys", "WdfLdr.sys")
    path = fso.BuildPath(windowsDir, "System32\drivers\" & name)
    If fso.FileExists(path) Then
        ver = fso.GetFileVersion(path)
        WScript.Echo name & " version: " & ver
        If Not FrameworkOkay(ver) Then
            WScript.Echo "BLOCK: compatible KMDF 1.9+ must already be installed."
            blockers = blockers + 1
        End If
    Else
        WScript.Echo "BLOCK: cannot find " & path
        blockers = blockers + 1
    End If
Next
WScript.Echo "Do not manually replace Microsoft framework files."
WScript.Echo ""
Set devices = wmi.ExecQuery("SELECT Name, DeviceID, Status, ConfigManagerErrorCode FROM Win32_PnPEntity")
For Each dev In devices
    If Not IsNull(dev.DeviceID) Then
        If InStr(1, dev.DeviceID, "USB\VID_2357&PID_0116", vbTextCompare) = 1 Then
            found = found + 1
            WScript.Echo "Adapter: " & dev.Name
            WScript.Echo "Device ID: " & dev.DeviceID
            WScript.Echo "Status: " & dev.Status
            WScript.Echo "Device Manager error code: " & dev.ConfigManagerErrorCode
        End If
    End If
Next
If found = 0 Then
    WScript.Echo "BLOCK: the exact USB\VID_2357&PID_0116 device was not found."
    WScript.Echo "Connect that adapter to a working USB port and rerun."
    blockers = blockers + 1
End If
WScript.Echo ""
Set drivers = wmi.ExecQuery("SELECT Name, State, PathName FROM Win32_SystemDriver WHERE Name = 'RtlWlanuVista' OR Name = 'RtlWlanu'")
For Each drv In drivers
    WScript.Echo "Driver service: " & drv.Name & "; state: " & drv.State
    WScript.Echo "Driver path: " & drv.PathName
Next
If blockers = 0 Then
    WScript.Echo "Prerequisite checks passed. Runtime compatibility is still UNTESTED."
    WScript.Echo "Use README.txt for the explicit, temporary unsigned-driver test procedure."
    WScript.Quit 0
Else
    WScript.Echo "Prerequisite checks blocked testing; do not proceed with installation."
    WScript.Quit 2
End If

Function FrameworkOkay(value)
    Dim parts, major, minor
    FrameworkOkay = False
    If Len(value) = 0 Then Exit Function
    parts = Split(value, ".")
    If UBound(parts) < 1 Then Exit Function
    If Not IsNumeric(parts(0)) Or Not IsNumeric(parts(1)) Then Exit Function
    major = CLng(parts(0))
    minor = CLng(parts(1))
    ' Retain the driver's actual major-1 ABI; do not assume a future major works.
    FrameworkOkay = (major = 1 And minor >= 9)
End Function
