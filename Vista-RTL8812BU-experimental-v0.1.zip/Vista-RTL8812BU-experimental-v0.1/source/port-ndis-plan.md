# NDIS 6.1 experimental port plan

This is a static, bounded plan for an **untested experimental Vista SP2 x64 candidate**, not a statement that the adapter works. The five changes below are internally consistent with the NDIS-version branches retained in the supplied driver. Physical hardware, Vista loading, association, and traffic testing remain necessary.

Original `rtwlanu.sys`: 11,831,816 bytes; SHA-256 `e1836af5d4297c51ff7c0d25292d0ec172412f45de8b48fe14fc20c3efb99c7a`.

No original binary has been modified by this audit. Exact guarded patch records are in `port-ndis-patches.json`; disassembly is in `port-ndis-evidence.txt`.

## Five equal-length NDIS changes

All addresses are preferred-image **virtual addresses**, based on ImageBase `0x10000`. Raw file offset in `.text` = VA minus `0x10c00`.

| Purpose | Instruction VA | Raw offset | Required original bytes | Proposed replacement |
|---|---:|---:|---|---|
| Minimum NDIS version 6.20 → 6.1 | `0x431f3` | `0x325f3` | `3d 14 00 06 00` | `3d 01 00 06 00` |
| Registered minor NDIS version decimal 20 → 1 | `0x43294` | `0x32694` | `c6 44 24 75 14` | `c6 44 24 75 01` |
| Adapter's internal version 6.20 → 6.1 | `0x444f9` | `0x338f9` | `41 c7 44 24 40 14 00 06 00` | `41 c7 44 24 40 01 00 06 00` |
| GENERAL_ATTRIBUTES length `0xe0` → `0xd8` | `0x14eb6` | `0x42b6` | `bf e0 00 00 00` | `bf d8 00 00 00` |
| GENERAL_ATTRIBUTES revision 2 → 1 | `0x14f00` | `0x4300` | `c6 44 24 61 02` | `c6 44 24 61 01` |

Each row changes exactly one immediate byte; instruction boundaries, relative branches, pointers, and stack unwinding are unchanged. Every original sequence and the entire input SHA-256 were checked against the supplied file. The builder must reject unexpected input and emit a separate file.

### Minimum check and miniport registration

The version call at VA `0x431ed` is imported `NdisGetVersion`. The original below-6.20 branch returns `STATUS_UNSUCCESSFUL`; the proposed comparison accepts 6.1 while still rejecting NDIS 6.0. The miniport characteristics remain revision 2, size `0x98`, major 6, now minor 1. Microsoft documents revision 2 of `NDIS_MINIPORT_DRIVER_CHARACTERISTICS` as adding direct-OID handlers for NDIS 6.1. Downgrading it to revision 1 is neither necessary nor proposed.

### Internal adapter version

Changing the advertised miniport version alone is insufficient. At VA `0x444f9`, the driver overwrites its own context version with `0x60014`, despite calling `NdisGetVersion` shortly before. Setting this to `0x60001` selects existing downlevel branches:

- VA `0x1398a`: older operation-mode capability configuration; later-version ExtAP enable path is skipped.
- VA `0x150be`: native Wi-Fi attributes revision 1, size `0x28`, at VAs `0x150d4`/`0x150d9`; the revision-2 path at `0x150e9` is skipped.
- VA `0x15641`: `jbe 0x158da` skips construction of virtual Wi-Fi and extended-AP attributes.
- The NDIS-version classification helper compares against 6.0, 6.1, 6.20, etc. at VAs `0x7fde6` onward; supplying 6.1 should select the retained older classification rather than Windows 7.

The entire `.text` scan found five literal `0x00060014` locations: VAs `0x150e3`, `0x156ff`, `0x431f4`, `0x444fe`, and `0x7fe06` (immediate-byte addresses). The other three are bounds/classification constants and should remain unchanged. Do not perform a global search-and-replace: unrelated radio register values also resemble Windows version numbers.

### General attributes and no-PM declaration

The routine at VA `0x14e94` builds an x64 `NDIS_MINIPORT_ADAPTER_GENERAL_ATTRIBUTES` on the stack, base `rsp+0x60`. Revision 1 ends after `AutoNegotiationFlags`, length `0xd8`; revision 2 appends `PowerManagementCapabilitiesEx` at offset `0xd8` and totals `0xe0`.

The proposed `EDI=0xd8` changes both the zero-fill length and the header length, since `DI` is stored at VA `0x14f05`. This leaves the original stack allocation intact. The existing tail store at `rsp+0x138` still writes a local stack slot but lies outside the advertised revision-1 length; no relocation or code cave is required. The old `PowerManagementCapabilities` field, offset `+0x48` (`rsp+0xa8`), is explicitly zeroed at VA `0x14f69`.

**NULL is documented:** Microsoft's current structure reference says, “If the miniport adapter is not power management-aware, the miniport driver should set PowerManagementCapabilities to NULL.” Revision 1 is documented for NDIS 6.0 and 6.1. This is a supported representation for an initial non-PM-aware experiment. It does not establish correct sleep/resume or waking support. Do not claim wake-on-WLAN, selective suspend, or suspend/resume works.

The local extended-PM initialization helper still executes, but its resulting pointer is outside the declared revision-1 structure. No operating-system API was observed in the short general-attributes construction path that would independently require NDIS 6.20.

## Existing power OID evidence

The candidate does not need to invent old power OID entry points:

- Advertised supported-OID list at VA `0xa8d280` includes `OID_PNP_SET_POWER` (`0xfd010101`) at VA `0xa8d340` and `OID_PNP_QUERY_POWER` (`0xfd010102`) at VA `0xa8d344`.
- Corresponding 0x60-byte dispatch records contain those OID numbers and names at VAs `0xa8f1b0` and `0xa8ef70`. Handler pointers at record offset `+0x58` point to VAs `0x40f9c` and `0x40bec`, respectively.
- The SET_POWER handler accepts the set operation and calls the real device-power transition routine at VA `0x48c84`, from VA `0x40fea`. That routine validates a four-byte power state and handles D0–D3 cases. The QUERY_POWER handler returns success for a valid four-byte query and reports required-length errors for shorter buffers.
- New `OID_PM_*` entries also remain. Their mere presence in supported OID tables is not by itself proof of a Vista failure, because Vista should not issue the newer OIDs. Their coexistence does not validate the old handler's runtime behavior.

These findings establish retained code, not power-management correctness. Leaving a NULL capability declaration is preferable to fabricating a legacy capability structure from the new one.

## Static import support

All **45 imported NDIS routines** were individually checked against Microsoft's DDI minimum-client requirements. Each is documented as supported in NDIS 6.0/Vista or earlier. Detailed names, reported minimums, and source URLs are saved in `port-ndis-import-support.json`, and retrieved documents are under `port-ddi/`. Six newer documentation locations use `mdlapi`/`nblapi`, rather than `ndis`; these were resolved successfully.

This rules out an obvious static NDIS import-version hole. It does not establish the target machine's actual export tables, KMDF installation, or compatibility of every structure passed to the APIs. KMDF 1.9 remains a prerequisite. The other kernel/HAL imports were not all cross-checked against physical Vista SP2 binaries by this report.

## Remaining experimental limits

- Native PHY, extended-station attributes, NET_BUFFER_LIST usage, per-OID structure revisions, USB behavior, cancellation, and teardown need further validation. A surviving Vista branch is encouraging, but not a proof that every newer common path is compatible.
- PE OS/image/subsystem versions and integrity/signature handling are separate changes outside the five NDIS instructions above. A modified file cannot retain its original valid Authenticode signature. Do not claim it is TP-Link/Microsoft-signed or silently install trust anchors.
- Keep the original package, original kernel file, and any pre-existing driver intact. Install a separately named, hardware-ID-scoped experimental package; no boot-start service. Any temporary-signature test and recovery instructions must be explicit. A reboot without the temporary F8 setting should restore signature enforcement. Removing only the experimental driver must remain possible through Safe Mode or offline recovery if needed.
- No successful hardware test is claimed. Required progression is loader/framework binding → Device Manager initialization → scan → association → DHCP → representative traffic → disconnect/replug → reboot behavior. Suspend/resume remains a separate, later test.

## Sources

- Official general-attributes reference, including NULL and revision requirements: https://raw.githubusercontent.com/MicrosoftDocs/windows-driver-docs-ddi/staging/wdk-ddi-src/content/miniportgeneralattributes/ns-miniportgeneralattributes-ndis_miniport_adapter_general_attributes.md (`port-ddi/general-attributes.md`).
- Official miniport-characteristics reference: https://raw.githubusercontent.com/MicrosoftDocs/windows-driver-docs-ddi/staging/wdk-ddi-src/content/ndis/ns-ndis-_ndis_miniport_driver_characteristics.md (`sys-audit-miniport-doc.md`).
- Microsoft NDIS versions: https://learn.microsoft.com/windows-hardware/drivers/network/overview-of-ndis-versions .
- Official old power OID behavior: https://raw.githubusercontent.com/MicrosoftDocs/windows-driver-docs/staging/windows-driver-docs-pr/network/oid-pnp-set-power.md and https://raw.githubusercontent.com/MicrosoftDocs/windows-driver-docs/staging/windows-driver-docs-pr/network/oid-pnp-query-power.md .
- Microsoft sample also marks legacy `PowerManagementCapabilities` optional: https://raw.githubusercontent.com/microsoft/Windows-driver-samples/main/network/ndis/netvmini/6x/adapter.c .
- SDK header mirror used to confirm x64 field order: https://raw.githubusercontent.com/tpn/winsdk-10/master/Include/10.0.16299.0/km/ndis.h . Official field/revision documentation above independently confirms the semantic mapping.
