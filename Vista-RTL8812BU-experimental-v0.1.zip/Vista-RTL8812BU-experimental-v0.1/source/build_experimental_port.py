#!/usr/bin/env python3
"""Build a guarded, unsigned Vista NDIS 6.1 experiment from one exact input.

This is not a source rebuild and does not prove Windows or hardware compatibility.
It intentionally preserves the KMDF 1.9 binding. Never use this on another driver
version. Original input files are opened read-only.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct

SOURCE_SHA256 = 'e1836af5d4297c51ff7c0d25292d0ec172412f45de8b48fe14fc20c3efb99c7a'
PATCHES = [
    (0x431f3, '3d14000600', '3d01000600',
     'Accept NDIS 6.1 at the explicit NdisGetVersion minimum check'),
    (0x43294, 'c644247514', 'c644247501',
     'Register the miniport as NDIS 6.1, preserving its supported revision-2 characteristics'),
    (0x444f9, '41c744244014000600', '41c744244001000600',
     'Select the retained NDIS 6.1 Native Wi-Fi paths, skipping Virtual Wi-Fi/ExtAP'),
    (0x14eb6, 'bfe0000000', 'bfd8000000',
     'Use the revision-1 general-attributes length for zeroing and Header.Size'),
    (0x14f00, 'c644246102', 'c644246101',
     'Submit revision-1 general attributes with existing NULL legacy PM capabilities'),
]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def parse_pe(data):
    if data[:2] != b'MZ':
        raise ValueError('Not an MZ image')
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    if data[pe:pe+4] != b'PE\0\0':
        raise ValueError('Missing PE signature')
    machine, sections = struct.unpack_from('<HH', data, pe+4)
    optional_size = struct.unpack_from('<H', data, pe+20)[0]
    opt = pe+24
    if machine != 0x8664 or struct.unpack_from('<H', data, opt)[0] != 0x20b:
        raise ValueError('Expected an AMD64 PE32+ image')
    imagebase = struct.unpack_from('<Q', data, opt+24)[0]
    section_table = opt+optional_size
    maps = []
    for index in range(sections):
        base = section_table+40*index
        virtual_size, rva, raw_size, raw = struct.unpack_from('<IIII', data, base+8)
        maps.append((rva, virtual_size, raw, raw_size))
    return opt, imagebase, maps


def va_to_offset(va, imagebase, maps):
    rva = va-imagebase
    for section_rva, virtual_size, raw, raw_size in maps:
        if section_rva <= rva < section_rva+raw_size:
            return raw+rva-section_rva
    raise ValueError(f'VA {va:#x} has no file-backed section')


def pe_checksum(data, checksum_offset):
    # IMAGE_OPTIONAL_HEADER.CheckSum is excluded from the 16-bit sum.
    total = 0
    for pos in range(0, len(data), 2):
        if checksum_offset <= pos < checksum_offset+4:
            continue
        word = data[pos] | ((data[pos+1] if pos+1 < len(data) else 0) << 8)
        total += word
        total = (total & 0xffff)+(total >> 16)
    total = (total & 0xffff)+(total >> 16)
    total = (total & 0xffff)+(total >> 16)
    return total+len(data)


def build(source, output, manifest_path):
    original = source.read_bytes()
    if sha256(original) != SOURCE_SHA256:
        raise ValueError('Input SHA-256 does not match the audited original. Refusing to patch.')
    opt, imagebase, maps = parse_pe(original)
    checksum_offset = opt+64
    original_checksum = struct.unpack_from('<I', original, checksum_offset)[0]
    if pe_checksum(original, checksum_offset) != original_checksum:
        raise ValueError('Original PE checksum is unexpected; refusing to patch.')
    data = bytearray(original)
    records = []
    for va, before_hex, after_hex, reason in PATCHES:
        before, after = bytes.fromhex(before_hex), bytes.fromhex(after_hex)
        if len(before) != len(after):
            raise ValueError('Instruction patch must retain its length')
        offset = va_to_offset(va, imagebase, maps)
        if data[offset:offset+len(before)] != before:
            raise ValueError(f'Unexpected instruction at VA {va:#x}')
        data[offset:offset+len(after)] = after
        records.append(dict(va=hex(va), file_offset=hex(offset), before=before_hex,
                            after=after_hex, purpose=reason))
    # The original Windows 7 PE header minima would remain after code adaptation.
    header_records = []
    for relative_offset, label in [(40, 'OS'), (44, 'Image'), (48, 'Subsystem')]:
        before = struct.unpack_from('<HH', data, opt+relative_offset)
        if before != (6, 1):
            raise ValueError(f'Unexpected {label} header version')
        struct.pack_into('<HH', data, opt+relative_offset, 6, 0)
        header_records.append(dict(field=label+' version', before=list(before), after=[6, 0]))
    # Remove the original embedded signature, which cannot attest to patched code.
    security_entry = opt+112+4*8
    certificate_offset, certificate_size = struct.unpack_from('<II', data, security_entry)
    if not certificate_offset or certificate_offset+certificate_size != len(data):
        raise ValueError('Expected a trailing certificate table; refusing unsafe truncation')
    struct.pack_into('<II', data, security_entry, 0, 0)
    del data[certificate_offset:]
    struct.pack_into('<I', data, checksum_offset, 0)
    checksum = pe_checksum(data, checksum_offset)
    struct.pack_into('<I', data, checksum_offset, checksum)
    if output.resolve() == source.resolve():
        raise ValueError('Never overwrite the original input')
    if output.exists() or manifest_path.exists():
        raise ValueError('Output exists; choose a fresh output directory')
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = {
        'status': 'EXPERIMENTAL_UNSIGNED_NOT_HARDWARE_TESTED',
        'source_sha256': SOURCE_SHA256,
        'output_sha256': sha256(data),
        'output_size': len(data),
        'output_file': output.name,
        'target': 'Vista SP2 x64, NDIS 6.1; requires KMDF 1.9 or newer compatible runtime',
        'instruction_patches': records,
        'pe_header_changes': header_records,
        'removed_original_certificate': {'file_offset': hex(certificate_offset), 'size': certificate_size},
        'pe_checksum': hex(checksum),
        'limits': ['Static validation only', 'No signature or catalog is supplied',
                   'No Windows installation, driver loading or hardware tests performed',
                   'Not a full source-level port or promise of compatibility'],
    }
    output.write_bytes(data)
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    result = build(args.source, args.output, args.manifest)
    print(json.dumps(result, indent=2))
