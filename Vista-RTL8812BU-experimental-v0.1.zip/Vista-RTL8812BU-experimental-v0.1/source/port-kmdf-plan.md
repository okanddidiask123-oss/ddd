# KMDF compatibility plan for the Vista experiment

## Recommendation

Preserve the original KMDF **1.9** bind requirement for the first candidate.
Use an already installed compatible Microsoft KMDF runtime, or install the
matching, correctly signed Microsoft 1.9 redistributable. Do not silently change
the bind to 1.7 merely to avoid supplying a framework prerequisite.

Stock Vista SP2 supplies KMDF 1.7, but this does not establish the user's actual
runtime version: previous hardware driver installers can have updated it.
Read the file versions of `%SystemRoot%\System32\drivers\Wdf01000.sys` and
`WdfLdr.sys` before deciding a redistributable is missing.

## Original binary evidence

- Original SYS SHA-256:
  `e1836af5d4297c51ff7c0d25292d0ec172412f45de8b48fe14fc20c3efb99c7a`.
- Preferred image base is `0x10000`; addresses here are preferred virtual
  addresses, not raw file offsets.
- `WDF_BIND_INFO` at VA `0x578110`: size `0x30`, major `1`, minor `9`, build
  `7600`, function count `396`; its function-table pointer is VA `0xa99f60`.
- Table storage is a fixed array, not an indirect pointer variable. Direct call
  targets from VA `0xa99f60` through `0xa99f60 + 395*8` were collected from the
  full objdump disassembly.
- The SYS also imports `WdfVersionBind`, `WdfVersionUnbind`,
  `WdfVersionBindClass`, and `WdfVersionUnbindClass` from `WDFLDR.SYS`.
  Export availability of every import in stock Vista's loader was not verified.
  Lowering the requested framework version alone does not change those imports.

## Promising but insufficient evidence for a 1.7 downgrade

All statically identified direct WDF API calls have table indices at most 366.
Microsoft's published function enumeration places the additional 1.9 APIs at
387–395. No direct call to those new APIs was found. This makes a separate,
carefully audited downgrade experiment more plausible, but does not prove it
safe: the client structure sizes, enum semantics, loader exports and all indirect
or computed accesses must also be checked. No such downgrade is included here.

The documented 1.9 changes include IO-queue configuration and timer structure
extensions. This driver does not directly call queue-creation or timer-creation
APIs, but it does pass other structures to USB, request, object and driver APIs.
The fact that their function indices are older is not a complete ABI audit.

## Practical packaging

If KMDF 1.9 or a compatible later runtime is already installed, do not force
CopyFiles of an unavailable coinstaller merely as a packaging convention. The
original INF has no WDF/coinstaller sections and relies on an existing runtime.
A preinstalled-runtime experimental INF can likewise retain that prerequisite
and make it explicit in its preflight/instructions.

If installing KMDF is necessary, use the matching Microsoft redistributable
`WdfCoInstaller01009.dll` for AMD64 and the documented INF installation sections.
No runtime file should be copied manually over the system's framework drivers.
The matching coinstaller must be obtained and its Microsoft signature verified;
it is not present in the user's supplied files.

The INF audit agent located Microsoft's documented WDK 8 redistributables link:
https://go.microsoft.com/fwlink/p/?LinkID=253170 . It contains the 1.9 and 1.11
redistributables according to Microsoft's installation-components documentation,
but the configured network policy blocked access to that host. This is an
acquisition limitation, not proof the component is unavailable.

## API map

| Table index | Function | Direct call sites |
| --- | --- | --- |
| 42 | `WdfDeviceGetIoTarget` | 1 |
| 116 | `WdfDriverCreate` | 1 |
| 121 | `WdfDriverRegisterTraceInfo` | 1 |
| 131 | `WdfFdoQueryForInterface` | 1 |
| 171 | `WdfIoTargetStart` | 3 |
| 172 | `WdfIoTargetStop` | 3 |
| 173 | `WdfIoTargetGetState` | 6 |
| 186 | `WdfIoTargetSendIoctlSynchronously` | 1 |
| 192 | `WdfMemoryCreate` | 2 |
| 193 | `WdfMemoryCreatePreallocated` | 1 |
| 194 | `WdfMemoryGetBuffer` | 3 |
| 200 | `WdfDeviceMiniportCreate` | 1 |
| 201 | `WdfDriverMiniportUnload` | 1 |
| 202 | `WdfObjectGetTypedContextWorker` | 43 |
| 208 | `WdfObjectDelete` | 5 |
| 247 | `WdfRequestCreate` | 4 |
| 249 | `WdfRequestReuse` | 3 |
| 253 | `WdfRequestSend` | 3 |
| 254 | `WdfRequestGetStatus` | 1 |
| 258 | `WdfRequestCancelSentRequest` | 2 |
| 260 | `WdfRequestSetCompletionRoutine` | 3 |
| 322 | `WdfUsbTargetDeviceCreate` | 1 |
| 323 | `WdfUsbTargetDeviceRetrieveInformation` | 1 |
| 324 | `WdfUsbTargetDeviceGetDeviceDescriptor` | 1 |
| 325 | `WdfUsbTargetDeviceRetrieveConfigDescriptor` | 2 |
| 329 | `WdfUsbTargetDeviceGetNumInterfaces` | 1 |
| 330 | `WdfUsbTargetDeviceSelectConfig` | 1 |
| 333 | `WdfUsbTargetDeviceSendControlTransferSynchronously` | 1 |
| 334 | `WdfUsbTargetDeviceFormatRequestForControlTransfer` | 1 |
| 342 | `WdfUsbTargetPipeIsInEndpoint` | 4 |
| 345 | `WdfUsbTargetPipeSetNoMaximumPacketSizeCheck` | 1 |
| 353 | `WdfUsbTargetPipeResetSynchronously` | 3 |
| 356 | `WdfUsbTargetPipeFormatRequestForUrb` | 2 |
| 357 | `WdfUsbInterfaceGetInterfaceNumber` | 1 |
| 365 | `WdfUsbInterfaceGetConfiguredPipe` | 1 |
| 366 | `WdfUsbTargetPipeWdmGetPipeHandle` | 2 |

## Sources and limitations

- Official Microsoft function enumeration, fetched with TLS verification:
  https://raw.githubusercontent.com/microsoft/Windows-Driver-Frameworks/main/src/publicinc/wdf/kmdf/1.15/wdffuncenum.h
- Microsoft KMDF version history (local `kmdf-version-history.md`):
  https://learn.microsoft.com/windows-hardware/drivers/wdf/kmdf-version-history
- Microsoft installation components:
  https://learn.microsoft.com/windows-hardware/drivers/wdf/installation-components-for-kmdf-drivers
- Local supporting files: `kmdf-table-uses.json`, `kmdf-driver-args.asm`,
  `kmdf-usb-args.asm`, `kmdf-entry.asm`.

This audit did not modify the original, install a framework, load a driver,
validate a Vista runtime, or test USB/Wi-Fi behavior. The API map is a static
analysis result, not a claim that a driver binary retargeted to 1.7 would work.
