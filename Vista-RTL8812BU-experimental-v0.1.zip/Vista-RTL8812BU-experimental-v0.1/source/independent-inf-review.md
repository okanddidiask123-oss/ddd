# Independent INF package review

Reviewed the assembled `driver` directory after generation of the experimental
SYS. This was a static review on Linux, not a Windows installation or hardware
test. No package file was modified during this review.

## Result

No required INF packaging correction was found.

- The INF decodes correctly as UTF-16LE, uses CRLF line endings, and has 31 unique
  sections.
- The model list contains only `USB\VID_2357&PID_0116`, using the AMD64 OS 6.0
  decoration; the revision-specific hardware ID can match the less specific
  VID/PID entry.
- `Vista_RTL8812bu.NT` has the expected network-class attributes and the native
  802.11 network binding names `ndis5` / `wlan,ethernet`.
- All referenced `AddReg`, `CopyFiles` and `AddService` sections exist. The
  selected service is consistently `RtlWlanuVista`, including the `Ndi\Service`
  value, and the service binary is `%12%\rtwlanu_vista.sys`.
- All three declared source/copied files exist in the same directory:
  `rtwlanu_vista.sys`, `PwrTblRate_Enc.txt` and `PwrTblLmt_Enc.txt`.
- Both power-table files are byte-identical to the supplied originals. The INF
  preserves the 16 selected OEM register-section bodies from the original;
  radio/regulatory configuration was not redesigned.
- There is no active `netvwifibus`, `vwifi`, `mdcwifi`, missing coinstaller, or
  missing catalog reference. Original vendor catalog files are not included.
- The provider and selected device description explicitly say **experimental**.
  No active setting claims this modified driver is Microsoft/WHQL/vendor signed
  or certified. Unused vendor description strings copied from the original are
  not selected devices.
- The user's reported `Wdf01000.sys` version **1.11.9200.16648** is newer than the
  retained KMDF 1.9 requirement; the package does not try to replace or downgrade
  it. This review relies on that user-reported installed-file version, not a
  runtime query of the Vista machine.

## Manual installation and signing

The package is deliberately unsigned and contains no `CatalogFile` directive.
Vista can process an unsigned INF with user consent, while Vista x64 kernel
signature enforcement separately governs loading the altered SYS. A temporary
F8 **Disable Driver Signature Enforcement** boot is a plausible test procedure;
it is not proof that this binary will load or work. The INF itself does not
change boot settings, trust stores or signature policy. Normal subsequent boots
can reject loading this unsigned SYS again.

The inherited `ExcludeFromSelect=*` flag can hide models from some manual
device-selection displays. Microsoft explicitly documents that matched devices
are still displayed in the Found New Hardware and Hardware Update Wizards on
Windows 2000 and later. Thus this is not an established blocker for updating the
existing matching adapter. Removing the block would be an optional clarity
improvement for a procedure that relies on selecting the model in a generic
Have Disk list.

References:

- [Microsoft INF ControlFlags documentation](https://learn.microsoft.com/windows-hardware/drivers/install/inf-controlflags-section)
- [Microsoft KMDF version history](https://learn.microsoft.com/windows-hardware/drivers/wdf/kmdf-version-history)

## Reviewed artifact hashes

| File | SHA-256 |
| --- | --- |
| `netrtwlanu_vista.inf` | `456f7ae4646e678edf7cdb13c7afe32b70bdd2af446f25594393ea357c031ad1` |
| `rtwlanu_vista.sys` | `7eec56c57eae34012684ad4febe5800f7aee9c56078ed61f94898a7adbbcdeb3` |
| `PwrTblRate_Enc.txt` | `85be58134c5b56b31f67a24b463a82c56bad415f7ea02fe5ed4f1e8461a0478b` |
| `PwrTblLmt_Enc.txt` | `5373de908d166879809f058d6ff7c4e7b755f17097f772ea955b5933a49a805e` |

Any later package edits require refreshing the relevant checks and hashes. INF
structure, source-file presence and framework-version prerequisites do not
validate the binary patch, Vista loading, NDIS registration, radio startup,
authentication, data traffic, unplug/replug or sleep/resume behavior.
