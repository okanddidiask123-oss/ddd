# Independent experimental binary review

**Static review passed; no runtime or hardware result is claimed.** Reviewed `driver/rtwlanu_vista.sys` against the uploaded original using independent PE parsing, whole-file byte comparison, checksum recomputation, and GNU objdump disassembly. The builder's functions were not imported or reused.

- Original SHA-256: `e1836af5d4297c51ff7c0d25292d0ec172412f45de8b48fe14fc20c3efb99c7a`.
- Candidate SHA-256: `7eec56c57eae34012684ad4febe5800f7aee9c56078ed61f94898a7adbbcdeb3`.
- Candidate length: 11,814,400 bytes.
- Independent PE checksum: `0x00b52430`, matching the stored checksum.
- The original attachment and investigation copy are byte-for-byte identical and retain the audited hash.

The candidate has exactly **five changed executable bytes**, corresponding to the five planned immediate operands:

| Preferred-image VA of instruction | Verified resulting instruction |
|---:|---|
| `0x431f3` | `cmp eax,0x60001` |
| `0x43294` | `mov BYTE PTR [rsp+0x75],0x1` |
| `0x444f9` | `mov DWORD PTR [r12+0x40],0x60001` |
| `0x14eb6` | `mov edi,0xd8` |
| `0x14f00` | `mov BYTE PTR [rsp+0x61],0x1` |

Instruction lengths and surrounding code are preserved. All other bytes in `.text` are unchanged. `.rdata`, `.data`, `.pdata`, `PAGE`, `INIT`, `.rsrc`, and `.reloc` are entirely unchanged, including imports, exception data, relocation data, entry point, and KMDF binding information.

In the retained file there are 15 changed bytes total: five code immediates and ten PE-header bytes. Header differences are limited to OS/image/subsystem minor versions 1 → 0, the PE checksum, and zeroing the security-directory entry. The original trailing certificate table at raw offset `0xb44600`, length 17,416 bytes, was removed exactly; all declared section raw extents remain inside the candidate. The candidate carries **no original valid signature or catalog**. No unexpected byte differences were found.

The user's reported `Wdf01000.sys` file version is `1.11.9200.16648`, a newer KMDF version than this binary's unchanged 1.9 binding. That report supports the framework prerequisite but does not prove successful binding on the target machine; this review did not inspect or load the user's Windows installation.

The review establishes that the file matches the bounded experimental patch plan. It does not establish that Vista loads it, Device Manager starts the adapter, scanning or traffic works, or sleep/resume is correct. See `independent-binary-review.json` for comparison details and `independent-binary-disassembly.txt` for the actual resulting instructions.
