# Retained Vista Native Wi-Fi path: experimental-port plan

Scope: original AMD64 `rtwlanu.sys`, SHA-256
`e1836af5d4297c51ff7c0d25292d0ec172412f45de8b48fe14fc20c3efb99c7a`.
Addresses are preferred virtual addresses, image base `0x10000`.
No original binary was modified by this analysis.

## Finding

The executable retains a coherent NDIS 6.1 Native 802.11 registration path.
The previously identified NDIS 6.20 requirements do not establish that the entire
Wi-Fi implementation must be rewritten. In this area a bounded experimental
candidate can select the existing older branches by changing the internal
adapter-context version, rather than blindly forcing newer structures into Vista.

This supports making a clearly experimental candidate. It does not establish
successful loading, association or data transfer on Vista; those remain hardware
tests.

## One internal version selects several older paths

Adapter-private state is reached through `[adapter + 0x6b0]`. Its offset `+0x40`
stores the driver's selected NDIS version. At VA `0x444f9`, the original code is:

```asm
41 c7 44 24 40 14 00 06 00    mov DWORD PTR [r12+0x40],0x60014
```

An experimental NDIS 6.1 candidate can change the immediate to `01 00 06 00`:

```asm
41 c7 44 24 40 01 00 06 00    mov DWORD PTR [r12+0x40],0x60001
```

Only byte VA `0x444fe` changes from `0x14` to `0x01`; corresponding original
`.text` file offset is `0x338fe`. This must be guarded by the full original hash
and expected instruction bytes, not applied to arbitrary Realtek versions.

This is in addition to the entry-version gate, miniport declaration, and general
adapter-attribute changes being analyzed separately. It does not replace them.

### Operation-mode capabilities

At VA `0x1398a`, the driver compares that private version with `0x60001`.
The `jbe 0x139e3` at `0x139b3` skips setting the ExtAP-enable byte and OR-ing
operation-mode bit `0x8` into the capabilities. NDIS 6.1 selection therefore
already avoids advertising that Windows 7 operation mode.

### Native 802.11 attributes

At VA `0x150be`, the same version is compared with `0x60001`:

- `<= 6.1` falls through VA `0x150d4`, setting header revision **1** and size
  **0x28**.
- `> 6.1` goes to VA `0x150e0`; the original 6.20 value produces revision **2**,
  size **0x38**.

The revision-1 size matches the baseline fields through `ExtSTAAttributes` in
`NDIS_MINIPORT_ADAPTER_NATIVE_802_11_ATTRIBUTES`. The appended `VWiFiAttributes`
and `ExtAPAttributes` fields belong to `NDIS_SUPPORT_NDIS620` in `ndis.h`.

After populating PHY and station attributes, VA `0x15641` checks the version
again. The `jbe 0x158da` at `0x15648` skips **all** of the Virtual Wi-Fi and
ExtAP allocation/construction between `0x1564e` and `0x158da` for NDIS 6.1.
It then calls `NdisMSetMiniportAttributes` at `0x158ea` with the baseline
revision-1 header. No new branch patch is necessary for these sites.

### Baseline station and PHY constructors remain present

- `0x14dd4` creates `DOT11_EXTSTA_ATTRIBUTES` with header revision **1** and size
  **0x80**. It fills the baseline station settings and infrastructure/ad-hoc
  authentication/cipher-pair arrays. It is not unconditionally a Windows 7-only
  station-attribute revision.
- `0x14c2c` creates `DOT11_PHY_ATTRIBUTES` with header revision **1** and size
  **0x444**, populating PHY state, supported power levels and rate mappings.
- Version-classification helper `0x7fdbc` explicitly recognizes `0x60001`,
  selecting its older class value 4, separately from class value 5 for 6.20.

## PHY-mode caution and a supported diagnostic fallback

Capability construction at `0x13958` includes legacy PHY types 4/5/6 and type 7
(HT). It uses type 7 for the modern wireless-mode capability paths inspected;
no unconditional VHT/type-8 attribute was identified in this constructor.
Vista's exact acceptance and display of the resulting type-7 capabilities was
not runtime-tested. Do not promise full 802.11ac throughput from a Vista port.

If the adapter loads but association/capability behavior fails, the original INF
already documents supported `WirelessMode` values:

- `4` = 802.11b/g (2.4 GHz conservative test).
- `1` = 802.11a (5 GHz legacy test).
- `8` = Auto (original default).
- `16` = 802.11b/g/n; `32` = 802.11a/n; `64` = 802.11a/n/ac.

Use documented registry values only. In particular, **3 is not the documented
b/g setting in this package**. Keep OEM RF front-end, transmit-power tables and
antenna settings intact. A diagnostic fallback is not a substitute for testing
the intended normal mode.

## Remaining limits

This analysis did not exhaustively reverse-engineer every OID handler or every
power/USB path. Wi-Fi source paths and correct interface headers can justify a
first experiment, but cannot prove whole-driver correctness statically. The
remaining port work includes the general attributes, framework availability,
PE/signature handling, Vista INF packaging and actual hardware tests. In
particular, old Windows x64 loading of a modified driver requires an explicit
development-signing/testing workflow; the original catalog cannot certify the
modified bytes.

## References and retained evidence

- `port-wifi-disassembly.txt`: Native 802.11 attribute construction and branches.
- `port-phy-capabilities.asm`: selected capability/PHY setup.
- `full-disassembly.asm`: full `.text` disassembly, useful for targeted searches.
- `sys-audit-ndis.h`, lines 11650–11695: baseline and appended Native 802.11 fields.
- `port-windot11.h`, lines 1698–1750 and 1756–1836: PHY/station field definitions.
- Header mirror (third-party, not Microsoft-authenticated release media):
  https://raw.githubusercontent.com/tpn/winsdk-10/master/Include/10.0.16299.0/shared/windot11.h

All literal `0x00060014` references inside `.text` were enumerated as an extra
cross-check: immediate VAs `0x150e3`, `0x156ff`, `0x431f4`, `0x444fe`, and
`0x7fe06`. These comprise conditional comparisons plus the identified gate and
internal assignment; they are not instructions to replace all five literals.
