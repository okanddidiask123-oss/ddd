# Proposed Vista x64 INF

`port-inf-proposed.inf` is an experimental packaging proposal for
`USB\VID_2357&PID_0116`, including revision 0210. It is UTF-16LE with a BOM and
CRLF line endings. It is not evidence of successful installation or radio use.

## Kept from the supplied Windows 7 package

- Demand start, NDIS load order group, and event-log configuration.
- All 16 selected OEM registry sections other than the replaced binding section,
  copied verbatim. This includes RF-front-end, antenna-path, USB mode, LED,
  power-management and encrypted transmit-power-table settings. No power-table
  contents or regulatory parameters were changed.
- Both `PwrTblRate_Enc.txt` and `PwrTblLmt_Enc.txt` in the driver-directory copy
  list, and the original string table.
- The original driver version identifies the binary's vendor base version;
  the provider and device description explicitly identify an experimental port.

## Packaging changes

- Only the user's USB ID is declared. Manufacturer/model OS decoration is now
  `NTamd64.6.0`, allowing Vista x64 to consider the package.
- Selected installation sections no longer include `netvwifibus.inf` or request
  the Windows 7 `VWiFiBus` services/filter registration. Stock Vista has no such
  bus driver. There is no attempt to copy Windows 7 system binaries onto Vista.
- Native 802.11 interface bindings are `UpperRange="ndis5"` and
  `LowerRange="wlan,ethernet"`; Windows 7 `mdcwifi` and `vwifi` entries are removed.
  The term `ndis5` here is the historical network binding name; it does not
  assert that the binary registers an NDIS 5 miniport.
- A supported, already installed **KMDF 1.9 or later** runtime is a prerequisite.
  As in the original selected package path, there is no `.Wdf` or coinstaller
  section: the binary binds to the preinstalled framework directly. The INF
  intentionally has no mandatory missing `WdfCoInstaller01009.dll` copy-list
  entry, so a machine which already has the runtime need not supply that
  redistributable again. This INF does not install or downgrade the framework.
- The test service name is `RtlWlanuVista`, bound through `Ndi\Service`, and its
  filename is `rtwlanu_vista.sys`, so the experiment does not overwrite a file
  named `rtwlanu.sys`. A scan found no exact ASCII/UTF-16 hardcoded `RtlWlanu`
  service or registry path in the SYS; the original filename appears in version
  metadata and its PDB path. That scan does not prove all possible dynamically
  constructed names absent. Runtime behavior still requires verification.
- This explicitly unsigned test INF has no `CatalogFile` directive and does not
  reference a nonexistent catalog. The original catalog cannot certify an
  altered INF or altered SYS and is not reused. This is not a normally signed
  distributable driver; any installation experiment must account for Vista x64
  signature enforcement. No signature policy is changed by this INF.
- The supplied optional Realtek user-mode DLLs/coinstaller are not installed,
  matching their absence from the original selected INF path. In particular,
  `Rtlihvs.dll` imports Windows 7's virtual-station notification API.

## Framework acquisition if the runtime is absent

Microsoft's official [Redistributable Framework Components documentation](https://learn.microsoft.com/windows-hardware/drivers/wdf/installation-components-for-kmdf-drivers)
states that **Windows Driver Kit 8 redistributable components** contains the
x86 and x64 coinstallers for KMDF 1.7, 1.9 and 1.11, including
`WdfCoInstaller01009.dll`. The official download link it supplies is:

<https://go.microsoft.com/fwlink/p/?LinkID=253170>

The Microsoft documentation was fetched from its public `MicrosoftDocs` source
repository and is retained as `kmdf-redistribution.md`; the actual download link
was blocked by the environment's configured proxy with **CONNECT 403**.
Therefore, no framework redistributable was acquired or validated here.

If acquired later, use the genuine **AMD64** file from the official distribution
and verify its Microsoft signature. A full coinstaller variant would add
`DDInstall.NT.CoInstallers`, a copy list with destination directory 11, and a
`CoInstallers32` multi-string entry
`"WdfCoInstaller01009.dll,WdfCoInstaller"`, together with a `.Wdf` section declaring
`KmdfService=RtlWlanuVista,Vista.Wdf.Service` and a referenced section declaring
`KmdfLibraryVersion=1.9`. Microsoft's
[coinstaller INF instructions](https://learn.microsoft.com/windows-hardware/drivers/wdf/installing-the-framework-s-co-installer)
document that layout. Merely adding the missing filename to this package would
not install the runtime.

Microsoft's [KMDF version history](https://learn.microsoft.com/windows-hardware/drivers/wdf/kmdf-version-history)
lists KMDF 1.9 as usable on Windows XP and later, and KMDF 1.11 as usable on Vista
and later. Updating the framework through its supported redistributable is a
supported prerequisite; binary-patching a requested 1.9 version down to stock
Vista's 1.7 is not established as compatible.

## Validation performed and outstanding

Static construction checks confirmed all selected OEM register sections match
the original bodies, all named INF string references resolve, the only model
is the specified USB ID, and no active `vwifi`, `mdcwifi`, `netvwifibus` or missing
coinstaller reference remains. This was not run through Windows InfVerif,
Chkinf, SetupAPI or a Vista driver installation.

The remaining binary changes, NDIS registration/attribute compatibility,
kernel API compatibility, framework presence, signing, actual driver loading,
association, WPA/WPA2 authentication, traffic, sleep/resume and disconnect/replug
behavior must be checked separately. The unmodified Windows 7 SYS is not made
Vista compatible by this INF alone.
