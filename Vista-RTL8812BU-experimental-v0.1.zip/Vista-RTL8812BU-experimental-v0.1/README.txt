RTL8812BU / USB VID_2357 PID_0116 -- Vista SP2 x64 experiment v0.1
================================================================

STATUS: UNSIGNED, STATICALLY CHECKED, NOT TESTED ON WINDOWS OR HARDWARE.
This is an experimental binary adaptation, not an official TP-Link/Realtek
release or a full source rebuild. It may fail to install, fail to initialize,
or crash Windows. Test on a recoverable Vista installation with your work saved.
Do not treat an installation success as proof that networking or sleep works.

The source files you uploaded are not overwritten. The adapted driver uses a
separate filename and service: rtwlanu_vista.sys / RtlWlanuVista.

WHAT THIS ACTUALLY CHANGES
------------------------
Five guarded instruction changes select the retained NDIS 6.1 Wi-Fi path,
adapt miniport registration and use Vista's general-attribute format. This
skips the conditional Virtual Wi-Fi / ExtAP setup. PE version minima are changed
to Vista; the original signature is removed because it cannot certify modified
code; the PE checksum is recalculated. The INF targets only your USB ID and
removes Windows 7 Virtual Wi-Fi installation dependencies.

OEM radio settings and both encrypted power-table files are preserved. No
firmware flashing or transmit-power/radio-limit changes are performed.
KMDF is NOT downgraded. The binary still requires a compatible Microsoft KMDF
1.9+ runtime. Your reported Wdf01000.sys 1.11.9200.16648 satisfies the version
requirement; PRECHECK also checks WdfLdr.sys and the actual connected device.

BEFORE INSTALLING
-----------------
1. Extract this entire ZIP to a writable local folder on Vista. Do not run files
   inside the ZIP. Connect only the matching adapter; use a working USB 2.0 port
   for the initial test if available.
2. Run PRECHECK.cmd. It only reads OS/device/framework information and writes
   Vista-diagnostic.txt beside the script. It installs nothing and changes no
   Windows settings. If it reports BLOCK, stop and send that text file.
3. Have a way to transfer logs without this Wi-Fi connection.

TEMPORARY UNSIGNED-DRIVER TEST
-----------------------------
There is no vendor signature or catalog for this derivative. A normal Vista
x64 boot is expected to reject it. No script in this package disables security.

4. Restart Vista. Press F8 before Windows loads, then choose
   "Disable Driver Signature Enforcement" for this boot only. This relaxes the
   signature requirement for other kernel drivers too during that boot. Do not
   permanently change boot/signature settings or import random certificates.
5. Open Device Manager. On the USB adapter choose Update Driver Software ->
   Browse my computer -> Let me pick -> Have Disk. Browse to
   driver\netrtwlanu_vista.inf. Select the experimental Vista RTL8812BU entry.
   If Windows displays an unsigned-publisher warning, this package is unsigned
   by design; proceed only as the deliberate test described here.
6. Do not use the original vendor setup.exe, the original catalog, or Windows 7
   Virtual Wi-Fi system files. Do not replace Wdf01000.sys or WdfLdr.sys manually.
   If Windows requests missing files or refuses installation, record the exact
   message and stop rather than forcing unrelated drivers onto the device.

WHAT TO TEST / SEND BACK
-----------------------
7. Check Device Manager. Record the exact device status and any error code.
   Run PRECHECK.cmd again and send the new Vista-diagnostic.txt.
8. If the device starts, check Vista's wireless network list. WLAN AutoConfig
   must be running (Services -> WLAN AutoConfig). First try a network you own
   using WPA2-Personal/AES; this experiment does not add WPA3 support to Vista.
9. Report separately whether networks are visible, association succeeds, an IP
   address is obtained, and data can actually be transferred. First test a
   short file transfer or page load; do not start with sleep/resume.
10. If the driver starts but scanning fails, report that result before changing
    advanced settings. The original Auto wireless mode is preserved. Existing
    b/g (mode 4) and a (mode 1) settings may be useful for later diagnostics.

No claim is made yet for 802.11ac rates, USB 3.0, reconnect reliability,
suspend/resume, AP/hotspot features, or sustained stability. Virtual Wi-Fi/AP
features are intentionally not part of this experiment.

ROLLBACK
--------
Unplug the adapter and reboot normally. The F8 signature exception is temporary;
normal signature enforcement resumes on the next ordinary boot. If Windows
crashes during loading, leave the adapter unplugged while booting (use Safe
Mode if needed). To remove the experiment, use Device Manager -> Uninstall and
select "Delete the driver software for this device" for this experimental
device/package. Do not uninstall the Microsoft WDF runtime. The isolated SYS
filename and service avoid overwriting the original Realtek binary/service,
but standard device installation does change this adapter's selected driver.

REPRODUCIBILITY / EVIDENCE
-------------------------
PATCH-MANIFEST.json lists exact changes and source/output hashes. The source/
folder contains the guarded Python builder and analysis. The builder accepts
only the exact uploaded SYS SHA-256 and refuses unexpected instruction bytes.
It is for review/reproduction on a Python 3 development machine; Vista does not
need Python to test the already-built package. STATIC-VALIDATION.json describes
the checks actually performed here. No Windows runtime tests are implied.
