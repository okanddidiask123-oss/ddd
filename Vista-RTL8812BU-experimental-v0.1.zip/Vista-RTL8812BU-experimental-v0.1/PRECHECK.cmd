@echo off
setlocal
set "PORT_CSCRIPT=%SystemRoot%\System32\cscript.exe"
if exist "%SystemRoot%\Sysnative\cscript.exe" set "PORT_CSCRIPT=%SystemRoot%\Sysnative\cscript.exe"
"%PORT_CSCRIPT%" //nologo "%~dp0Precheck.vbs" > "%~dp0Vista-diagnostic.txt" 2>&1
set "PORT_RESULT=%ERRORLEVEL%"
type "%~dp0Vista-diagnostic.txt"
echo.
echo Saved beside this script as Vista-diagnostic.txt.
echo This check does not install drivers or change Windows settings.
echo It cannot prove that the experimental driver will work.
echo.
pause
exit /b %PORT_RESULT%
